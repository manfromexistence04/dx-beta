const SinglePost = () => {
    return <div>SinglePost</div>;
  };
  
export default SinglePost;