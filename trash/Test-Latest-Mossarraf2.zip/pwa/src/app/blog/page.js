const BlogPage = () => {
    return <div>BlogPage</div>;
  };
  
export default BlogPage;