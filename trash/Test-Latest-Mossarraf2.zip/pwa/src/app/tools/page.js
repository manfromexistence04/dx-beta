const ToolsPage = () => {
    return <div>ToolsPage</div>;
  };
  
export default ToolsPage;