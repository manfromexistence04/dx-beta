const AboutCompanyPage = () => {
    return <div>AboutCompanyPage</div>;
  };
  
export default AboutCompanyPage;