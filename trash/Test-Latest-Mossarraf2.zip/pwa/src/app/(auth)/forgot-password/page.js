const ForgotPasswordPage = () => {
    return <div>ForgotPasswordPage</div>;
  };
  
export default ForgotPasswordPage;