const AccountPage = () => {
    return <div>AccountPage</div>;
  };
  
export default AccountPage;