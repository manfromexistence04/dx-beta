const Servicespage = () => {
    return <div>Servicespage</div>;
  };
  
export default Servicespage;